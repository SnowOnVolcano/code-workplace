#include "head.h"

int lineNum = 1;
int isMinuLine = 0;
